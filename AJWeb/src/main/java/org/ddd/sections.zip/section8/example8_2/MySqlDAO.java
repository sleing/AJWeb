package org.ddd.section8.example8_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class MySqlDAO {
	public static Connection getConnection()  throws Exception{
		String driverName = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/simple";
		String userName = "root";
		String password = "000000";
		Class.forName(driverName);
		Connection con = DriverManager.getConnection(url, userName, password);
		return con;
	}
	public static Statement getStatement(Connection conn) throws Exception{
		Statement stmt = conn.createStatement();
		return stmt;
	}
}
