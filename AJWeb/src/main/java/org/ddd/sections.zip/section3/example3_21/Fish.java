package org.ddd.section3.example3_21;

public class Fish   extends Animal{
}
