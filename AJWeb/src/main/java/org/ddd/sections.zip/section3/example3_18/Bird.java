package org.ddd.section3.example3_18;

public class Bird extends Animal {
}
