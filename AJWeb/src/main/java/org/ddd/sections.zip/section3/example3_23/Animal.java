package org.ddd.section3.example3_23;

public class Animal<T> {
	public T get(){return null;}
}
