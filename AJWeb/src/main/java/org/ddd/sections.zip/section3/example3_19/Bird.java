package org.ddd.section3.example3_19;

public class Bird extends Animal {
}
