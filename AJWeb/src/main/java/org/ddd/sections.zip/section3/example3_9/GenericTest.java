package org.ddd.section3.example3_9;

public class GenericTest {
	public static void  main(String[] args) throws Exception{
		
	}
}
