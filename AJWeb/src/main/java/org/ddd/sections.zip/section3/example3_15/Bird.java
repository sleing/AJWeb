package org.ddd.section3.example3_15;

public class Bird  extends Animal {
}
