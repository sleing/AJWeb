package org.ddd.section3.example3_6;

public class Person<T> {
	protected T t;
	public Person(T t){
		this.t = t;
	}
	public String toString(){
		return "变量t的类型是：" + t.getClass().getCanonicalName();
	}
}
