package org.ddd.section3.example3_25;

public class Parrot extends Bird {
}
