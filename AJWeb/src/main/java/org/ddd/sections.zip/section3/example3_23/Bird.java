package org.ddd.section3.example3_23;

public class Bird extends Animal<String>{
	public String get(){return null;}
}
