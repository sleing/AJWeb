package org.ddd.section3.example3_20;

public interface Speakable {
	public String speak();
}
