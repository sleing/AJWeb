package org.ddd.section3.example3_15;

public class Parrot extends Bird implements Speakable, Flyable {
	@Override
	public String speak() {
		return "我是一只鹦鹉！";
	}
}
