package org.ddd.section3.example3_10;

public class Car {

}
