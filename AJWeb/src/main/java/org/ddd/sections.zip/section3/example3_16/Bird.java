package org.ddd.section3.example3_16;

public class Bird extends Animal {
}
