package org.ddd.section3.example3_9;

public interface Factory<T> {
	public T create();
}
