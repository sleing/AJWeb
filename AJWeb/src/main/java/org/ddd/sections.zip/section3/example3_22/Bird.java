package org.ddd.section3.example3_22;

public class Bird extends Animal<String>{
	public void set(String name){}
}
