package org.ddd.section3.example3_10;

public interface Factory<T> {
	public T create();
}
