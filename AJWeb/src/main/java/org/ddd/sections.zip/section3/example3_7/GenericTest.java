package org.ddd.section3.example3_7;



public class GenericTest<T> {
	public static void  main(String[] args){
		
	}
}
