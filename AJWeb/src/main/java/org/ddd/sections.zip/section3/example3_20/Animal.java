package org.ddd.section3.example3_20;

public class Animal {
}
