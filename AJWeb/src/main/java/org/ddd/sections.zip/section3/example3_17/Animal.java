package org.ddd.section3.example3_17;

public class Animal {
}
