package org.ddd.section3.example3_15;

public interface Flyable {
}
