package org.ddd.section3.example3_21;
 
public class Bird extends Animal {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
