package org.ddd.section3.example3_13;

public class BenzCar extends Car {
	public BenzCar(){
		System.out.println("生产奔驰汽车！");
	}
}
