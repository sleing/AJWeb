package org.ddd.section3.example3_14;

public class Sortor {
	public <V extends Comparable<V>> V getMax(V x, V y){ 
		if(x.compareTo(y) > 0){
			return x;
		}else{
			return y;
		}
	}
}
