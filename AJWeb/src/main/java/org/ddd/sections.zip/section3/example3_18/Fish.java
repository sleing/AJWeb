package org.ddd.section3.example3_18;

public class Fish extends Animal {
}
