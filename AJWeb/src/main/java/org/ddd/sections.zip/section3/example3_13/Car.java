package org.ddd.section3.example3_13;

public class Car {
}
