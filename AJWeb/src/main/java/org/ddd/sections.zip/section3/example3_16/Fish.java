package org.ddd.section3.example3_16;

public class Fish extends Animal {
}
