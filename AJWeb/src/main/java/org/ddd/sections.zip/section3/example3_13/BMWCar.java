package org.ddd.section3.example3_13;

public class BMWCar extends Car {
	public BMWCar(){
		System.out.println("生产宝马汽车！");
	}
}
