package org.ddd.section3.example3_22;

public class Animal<T> {
	public void set(T t){}
}
