package org.ddd.section4.example4_3;

public class Person {
	@Deprecated
	public String name;
}
