package org.ddd.section4.example4_10;

public interface AnnotationProcessor {
	public boolean process(Class<?> clazz) throws Exception;
}
