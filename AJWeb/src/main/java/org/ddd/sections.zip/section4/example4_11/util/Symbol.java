package org.ddd.section4.example4_11.util;

public class Symbol {
	public static final String BLANK = " ";
	public static final String TAB = "\t";
	public static final String LINE = "\n";
}
