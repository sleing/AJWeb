package org.ddd.section4.example4_7;


@Entity(name = "Person")
public class Person {
	@Test
	public void speak(String message){}
}
