package org.ddd.section4.example4_1;

@Deprecated
public abstract class Person {
}
