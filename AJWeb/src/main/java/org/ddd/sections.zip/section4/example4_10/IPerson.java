package org.ddd.section4.example4_10;
public  interface IPerson{
	public void speak (java.lang.String arg0);
	public void useTool (java.lang.String arg0);
}