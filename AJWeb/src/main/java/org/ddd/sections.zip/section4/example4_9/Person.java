package org.ddd.section4.example4_9;

public class Person {
	@ID("personID")
	private Integer id;
}
