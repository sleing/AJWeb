package org.ddd.section4.example4_11.processor;

public interface IProcessor {
	public String process(String url) throws Exception;
}
