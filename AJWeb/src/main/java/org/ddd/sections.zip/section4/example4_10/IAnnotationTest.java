package org.ddd.section4.example4_10;
public  interface IAnnotationTest{
}