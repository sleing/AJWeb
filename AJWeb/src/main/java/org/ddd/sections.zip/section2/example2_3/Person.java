package org.ddd.section2.example2_3;

public class Person {
	class Tool{
	}
	interface Communication{
		public void speak();
	}
}

