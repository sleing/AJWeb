package org.ddd.section2.example2_7;

public class Course {
	static{
		System.out.println("Course prepare!");
	}
}


