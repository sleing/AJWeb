package org.ddd.section2.example2_6;

public class Person {
	static {
		System.out.println("Person prepare!");
	}
}

