package org.ddd.section2.example2_6;

public class Teacher extends Person {
	static{
		System.out.println("Teacher prepare!");
	}
}
