package org.ddd.section2.example2_8;

public class Person {
}
