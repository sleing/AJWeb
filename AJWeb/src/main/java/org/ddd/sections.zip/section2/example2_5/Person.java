package org.ddd.section2.example2_5;

public class Person {
	public static final int ID = 1;
	static {
		System.out.println("Person prepare!");
	}
}

