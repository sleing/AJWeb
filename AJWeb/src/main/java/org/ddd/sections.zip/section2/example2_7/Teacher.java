package org.ddd.section2.example2_7;

public class Teacher {
	static{
		System.out.println("Teacher prepare!");
	}
	public static Course course;
}

