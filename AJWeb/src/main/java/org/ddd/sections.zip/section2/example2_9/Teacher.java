package org.ddd.section2.example2_9;

public class Teacher extends Person {

}
