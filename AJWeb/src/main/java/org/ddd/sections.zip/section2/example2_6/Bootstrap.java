package org.ddd.section2.example2_6;

public class Bootstrap {
	public static void main(String[] args){
		new Teacher();
	}
}


