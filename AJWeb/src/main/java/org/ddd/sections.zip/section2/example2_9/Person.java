package org.ddd.section2.example2_9;

public class Person {
	public void speak(String message){
		System.out.println(message);
	}
}
