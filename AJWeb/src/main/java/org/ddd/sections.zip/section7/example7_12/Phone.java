package org.ddd.section7.example7_12;

public class Phone implements Gift {

 
	public void makeSbHappy() {
		System.out.println("phone make you happy!!!");
	}

}
