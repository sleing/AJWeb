package org.ddd.section7.example7_12;

public class Flower implements Gift {

	 
	public void makeSbHappy() {
		System.out.println("flower make you happy!!!");
	}
}
