package org.ddd.section7.example7_4;

import java.io.Serializable;

public class Tool implements Serializable{
//	private String toolName = "knife";
}
