package org.ddd.section7.example7_12;

public class Chocolate implements Gift {

	public void makeSbHappy() {
		System.out.println("Chocolate make you happy!!!");
	}
}
