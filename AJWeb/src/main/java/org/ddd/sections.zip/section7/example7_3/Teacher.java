package org.ddd.section7.example7_3;

import java.io.Serializable;

public class Teacher extends Person implements Serializable {
	private static final long serialVersionUID = 1L;
	private String position = "无";
}
