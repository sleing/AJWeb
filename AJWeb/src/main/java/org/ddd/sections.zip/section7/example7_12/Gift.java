package org.ddd.section7.example7_12;

public interface Gift {
	public void makeSbHappy();
}
